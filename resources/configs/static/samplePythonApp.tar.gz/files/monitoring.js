exports.default = {
  type: 'monitoring',
  details: {
    title: 'samplePythonApp Application',
    label: '',
    mainSection: 1,
    position: '1',
    id: 'samplePythonApp',
    url: '/samplePythonApp'
  },
  sections: [
    {
      details: {
        title: 'System',
        label: 'System',
        position: '1',
        id: 'system',
        readOnly: true,
        url: '/system',
        dataSource: {
          configs: [],
          system: {
            topics: [
              'liveValue.production.this.samplePythonApp.0.inputs.boolIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.int8In.',
              'liveValue.production.this.samplePythonApp.0.inputs.int16In.',
              'liveValue.production.this.samplePythonApp.0.inputs.int32In.',
              'liveValue.production.this.samplePythonApp.0.inputs.int64In.',
              'liveValue.production.this.samplePythonApp.0.inputs.uint8In.',
              'liveValue.production.this.samplePythonApp.0.inputs.uint16In.',
              'liveValue.production.this.samplePythonApp.0.inputs.uint32In.',
              'liveValue.production.this.samplePythonApp.0.inputs.uint64In.',
              'liveValue.production.this.samplePythonApp.0.inputs.floatIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.doubleIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.stringIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.jsonIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.voltageIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.currentIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.percentIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.tempIn.',
              'liveValue.production.this.samplePythonApp.0.inputs.flagIn.',
              'liveValue.production.this.samplePythonApp.0.outputs.voltageOut.',
              'liveValue.diagnostics.this.samplePythonApp.0.diag.opStatus.',
              'liveValue.diagnostics.this.samplePythonApp.0.diag.version.',
              'liveValue.diagnostics.this.samplePythonApp.0.diag.cycleCount.',
              'liveValue.diagnostics.this.samplePythonApp.0.diag.failCount.',
              'liveValue.state.this.samplePythonApp.0.state.powerIn.',
              'liveValue.state.this.samplePythonApp.0.state.lastCycleTime.',
              'liveValue.state.this.samplePythonApp.0.state.avgCycleTime.'
            ],
          },
        },
      },
      content: [
        {
          id: 'system',
          title: 'System',
          layout: [
            {
              production: { xs: 12 },
              diagnostics: { xs: 12 },
              state: { xs: 12 },
            },
          ],
          ui: {
            production: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.boolIn': { xs: 1 },
                    'liveValue.production.this.samplePythonApp.0.inputs.int8In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.int16In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.int32In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.int64In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.uint8In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.uint16In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.uint32In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.uint64In': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.floatIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.doubleIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.stringIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.jsonIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.voltageIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.currentIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.percentIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.tempIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.inputs.flagIn': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.outputs.voltageOut': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.boolIn': {
                      type: 'checkbox',
                      title: 'Bool Input',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.boolIn.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.int8In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Int8 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.int8In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.int16In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Int16 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.int16In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.int32In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Int32 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.int32In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.int64In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Int64 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.int64In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.uint8In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Uint8 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.uint8In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.uint16In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Uint16 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.uint16In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.uint32In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Uint32 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.uint32In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.uint64In': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Uint64 Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.uint64In.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.floatIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Float Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.floatIn.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.doubleIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Double Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.doubleIn.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.stringIn': {
                      type: 'text',
                      placeholder: 'stringIn',
                      title: 'String Input',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.stringIn.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.jsonIn': {
                      type: 'text',
                      placeholder: 'jsonIn',
                      title: 'JSON Input',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.jsonIn.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.voltageIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Voltage Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.voltageIn.'],
                      unitConversion: {
                        category: 'VOLT',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.currentIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Current Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.currentIn.'],
                      unitConversion: {
                        category: 'CUR',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.percentIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Percent Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.percentIn.'],
                      unitConversion: {
                        category: 'PRCNT',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.tempIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Temperature Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.tempIn.'],
                      unitConversion: {
                        category: 'TEMP',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.inputs.flagIn': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Flag Input',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.inputs.flagIn.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.outputs.voltageOut': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Voltage Output',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.outputs.voltageOut.'],
                      unitConversion: {
                        category: 'VOLT',
                        showUnits: true,
                      }
                    }
                  }
                ]
              }
            },
            diagnostics: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.opStatus': { xs: 3 },
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.version': { xs: 3 },
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.cycleCount': { xs: 3 },
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.failCount': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.opStatus': {
                      type: 'text',
                      placeholder: 'opStatus',
                      title: 'Operation Status',
                      readOnly: true,
                      tagsRelated: ['liveValue.diagnostics.this.samplePythonApp.0.diag.opStatus.']
                    }
                  },
                  {
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.version': {
                      type: 'text',
                      placeholder: 'version',
                      title: 'Version',
                      readOnly: true,
                      tagsRelated: ['liveValue.diagnostics.this.samplePythonApp.0.diag.version.']
                    }
                  },
                  {
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.cycleCount': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Cycle Count',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.diagnostics.this.samplePythonApp.0.diag.cycleCount.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.diagnostics.this.samplePythonApp.0.diag.failCount': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Fail Count',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.diagnostics.this.samplePythonApp.0.diag.failCount.'],
                      unitConversion: {
                        category: 'NONE',
                        showUnits: true,
                      }
                    }
                  }
                ]
              }
            },
            state: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.state.this.samplePythonApp.0.state.powerIn': { xs: 3 },
                    'liveValue.state.this.samplePythonApp.0.state.lastCycleTime': { xs: 3 },
                    'liveValue.state.this.samplePythonApp.0.state.avgCycleTime': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.state.this.samplePythonApp.0.state.powerIn': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Power In',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.state.this.samplePythonApp.0.state.powerIn.'],
                      unitConversion: {
                        category: 'POW',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.state.this.samplePythonApp.0.state.lastCycleTime': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Last Cycle Execution Time',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.state.this.samplePythonApp.0.state.lastCycleTime.'],
                      unitConversion: {
                        category: 'TIME.S',
                        showUnits: true,
                      }
                    }
                  },
                  {
                    'liveValue.state.this.samplePythonApp.0.state.avgCycleTime': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Average Cycle Execution Time',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.state.this.samplePythonApp.0.state.avgCycleTime.'],
                      unitConversion: {
                        category: 'TIME.S',
                        showUnits: true,
                      }
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    },
    {
      details: {
        title: 'All Widgets',
        label: 'All Widgets',
        position: '2',
        id: 'AllWidgets_202503071212',
        readOnly: true,
        url: '/AllWidgets_202503071212',
        dataSource: {
          configs: [],
          AllWidgets_202503071212: {
            topics: [
              'liveValue.production.this.samplePythonApp.0.boolone.',
              'liveValue.production.this.samplePythonApp.0.bool2.',
              'liveValue.production.this.samplePythonApp.0.bool3.',
              'liveValue.production.this.samplePythonApp.0.bool4.',
              'liveValue.production.this.samplePythonApp.0.bool5.',
              'liveValue.production.this.samplePythonApp.0.int1.',
              'liveValue.production.this.samplePythonApp.0.int2.',
              'liveValue.production.this.samplePythonApp.0.int3.',
              'liveValue.production.this.samplePythonApp.0.newdatapoint.',
              'liveValue.production.this.samplePythonApp.0.newdatapoint1.',
              'liveValue.production.this.samplePythonApp.0.float1.',
              'liveValue.production.this.samplePythonApp.0.float2.',
              'liveValue.production.this.samplePythonApp.0.float3.',
              'liveValue.production.this.samplePythonApp.0.string1.',
              'liveValue.production.this.samplePythonApp.0.string2.',
              'liveValue.production.this.samplePythonApp.0.string3.',
              'liveValue.production.this.samplePythonApp.0.tag1.',
              'liveValue.production.this.samplePythonApp.0.tag2.'
            ],
          },
        },
      },
      content: [
        {
          id: 'AllWidgets_202503071212',
          title: 'All Widgets',
          layout: [
            {
              BoolWidgets_202503071212: { xs: 12 },
              IntegerWidgets_202503071212: { xs: 12 },
              FloatWidgets_202503071212: { xs: 12 },
              StringWidgets_202503071212: { xs: 12 },
              TagWidget_202503071212: { xs: 12 },
            },
          ],
          ui: {
            BoolWidgets_202503071212: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.boolone': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.bool2': { xs: 3 },
                    buttonPublishBoolWidgets_202503071212bool3: { xs: 3 },
                    buttonPublishBoolWidgets_202503071212bool4: { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.bool5': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.boolone': {
                      type: 'checkbox',
                      title: 'boolOne',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.boolone.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.bool2': {
                      type: 'toggle',
                      title: 'bool2',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.bool2.']
                    }
                  },
                  {
                    buttonPublishBoolWidgets_202503071212bool3: {
                      type: 'button',
                      text: 'bool3',
                      onClick: {
                        fn: 'publishMultipleTags',
                        parameters: {
                          fields: {
                            'liveValue.production.this.samplePythonApp.0.bool3': {
                              singleTagName: 'liveValue.production.this.samplePythonApp.0.bool3.',
                              type: 'plBool',
                              value: false,
                            }
                          },
                        },
                      },
                    },
                  },
                  {
                    buttonPublishBoolWidgets_202503071212bool4: {
                      type: 'button',
                      text: 'bool4',
                      onClick: {
                        fn: 'publishMultipleTags',
                        parameters: {
                          fields: {
                            'liveValue.production.this.samplePythonApp.0.bool4': {
                              singleTagName: 'liveValue.production.this.samplePythonApp.0.bool4.',
                              type: 'plBool',
                              value: true,
                            }
                          },
                        },
                      },
                    },
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.bool5': {
                      type: 'checkbox',
                      title: 'bool5',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.bool5.']
                    }
                  }
                ]
              }
            },
            IntegerWidgets_202503071212: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.int1': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.int1Label': { xs: 9 },
                    'liveValue.production.this.samplePythonApp.0.int2': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.int3': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.newdatapoint': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.newdatapoint1': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.int1': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'int1',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.int1.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.int1Label': {
                      type: 'label',
                      text: 'My Int',
                      alignment: 'left',
                      modifier: ''
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.int2': {
                      type: 'horizontalChart',
                      dataType: 'float',
                      title: 'int2',
                      showControls: false,
                      readOnly: true,
                      chartDefinitions: {
                        data: 0,
                        minValue: 0,
                        maxValue: 24,
                        units: '',
                        decimals: 3
                      },
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.int2.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.int3': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'int3',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.int3.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.newdatapoint': {
                      type: 'checkbox',
                      title: 'NewDataPoint',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.newdatapoint.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.newdatapoint1': {
                      type: 'checkbox',
                      title: 'NewDataPoint 1',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.newdatapoint1.']
                    }
                  }
                ]
              }
            },
            FloatWidgets_202503071212: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.float1': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.float1Label': { xs: 9 },
                    'liveValue.production.this.samplePythonApp.0.float2': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.float3': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.float1': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'float1',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.float1.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.float1Label': {
                      type: 'label',
                      text: 'My Float',
                      alignment: 'left',
                      modifier: ''
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.float2': {
                      type: 'horizontalChart',
                      dataType: 'float',
                      title: 'float2',
                      showControls: false,
                      readOnly: true,
                      chartDefinitions: {
                        data: 0,
                        minValue: 0,
                        maxValue: 100,
                        units: '',
                        decimals: 3
                      },
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.float2.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.float3': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'float3',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.float3.']
                    }
                  }
                ]
              }
            },
            StringWidgets_202503071212: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.string1': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.string2': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.string2Label': { xs: 6 },
                    'liveValue.production.this.samplePythonApp.0.string3': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.string1': {
                      type: 'password',
                      placeholder: '',
                      title: 'string1',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.string1.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.string2': {
                      type: 'text',
                      placeholder: '',
                      title: 'string2',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.string2.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.string2Label': {
                      type: 'label',
                      text: 'My String',
                      alignment: 'left',
                      modifier: ''
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.string3': {
                      type: 'text',
                      placeholder: '',
                      title: 'string3',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.string3.']
                    }
                  }
                ]
              }
            },
            TagWidget_202503071212: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.tag1': { xs: 3 },
                    'liveValue.production.this.samplePythonApp.0.tag1Label': { xs: 9 },
                    'liveValue.production.this.samplePythonApp.0.tag2': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.tag1': {
                      type: 'text',
                      placeholder: '',
                      title: 'tag1',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.tag1.']
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.tag1Label': {
                      type: 'label',
                      text: '',
                      alignment: 'left',
                      modifier: ''
                    }
                  },
                  {
                    'liveValue.production.this.samplePythonApp.0.tag2': {
                      type: 'text',
                      placeholder: '',
                      title: 'tag2',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.tag2.']
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  ]
}
