exports.default = {
  type: 'application',
  details: {
    title: 'samplePythonApp Application',
    label: '',
    mainSection: 1,
    position: '1',
    id: 'samplePythonApp',
    url: '/samplePythonApp'
  },
  sections: [
    {
      details: {
        title: 'ACE Configured Tag Select',
        label: 'ACE Configured Tag Select',
        position: '1',
        id: 'AceConfiguredTagSelect_202503071212',
        url: '/AceConfiguredTagSelect_202503071212'
      },
      content: [
        {
          id: 'AceConfiguredTagSelect_202503071212',
          title: 'ACE Configured Tag Select',
          layout: [
            {
              IoTagSelect_202503071212: { xs: 12 },
            },
          ],
          ui: {
            IoTagSelect_202503071212: {
              type: 'groupBox',
              title: 'Tag Selections',
              children: {
                layout: [
                  {
                    'inputTag': { xs: 3 },
                    'outputTag': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'inputTag': {
                      type: 'text',
                      placeholder: '',
                      title: 'Input Tag',
                      tagsRelated: ['inputTag.']
                    }
                  },
                  {
                    'outputTag': {
                      type: 'text',
                      placeholder: '',
                      title: 'Output Tag',
                      tagsRelated: ['outputTag.']
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  ]
}
