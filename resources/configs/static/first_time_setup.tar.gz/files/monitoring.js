exports.default = {
  type: 'monitoring',
  details: {
    title: 'Sample Python HCC2 Application',
    label: '',
    mainSection: 1,
    position: '1',
    id: 'samplePythonApp',
    url: '/samplePythonApp'
  },
  sections: [
    {
      details: {
        title: 'NewGeneralSection',
        label: 'NewGeneralSection',
        position: '1',
        id: 'Newgeneralsection_202503121253',
        readOnly: true,
        url: '/Newgeneralsection_202503121253',
        dataSource: {
          configs: [],
          Newgeneralsection_202503121253: {
            topics: [
              'liveValue.production.this.samplePythonApp.0.sampleGeneral.'
            ],
          },
        },
      },
      content: [
        {
          id: 'Newgeneralsection_202503121253',
          title: 'NewGeneralSection',
          layout: [
            {
              SampleGeneral_202503121214: { xs: 12 },
            },
          ],
          ui: {
            SampleGeneral_202503121214: {
              type: 'groupBox',
              title: 'Sample General [First Time Setup]',
              children: {
                layout: [
                  {
                    'liveValue.production.this.samplePythonApp.0.sampleGeneral': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.samplePythonApp.0.sampleGeneral': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Sample General',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.samplePythonApp.0.sampleGeneral.']
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  ]
}
