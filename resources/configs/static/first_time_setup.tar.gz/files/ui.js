exports.default = {
  type: 'application',
  details: {
    title: 'Sample Python HCC2 Application',
    label: '',
    mainSection: 1,
    position: '1',
    id: 'samplePythonApp',
    url: '/samplePythonApp'
  },
  sections: [
    {
      details: {
        title: 'NewConfigSection',
        label: 'NewConfigSection',
        position: '1',
        id: 'Newconfigsection_202503121218',
        url: '/Newconfigsection_202503121218'
      },
      content: [
        {
          id: 'Newconfigsection_202503121218',
          title: 'NewConfigSection',
          layout: [
            {
              SampleConfig_202503121220: { xs: 12 },
            },
          ],
          ui: {
            SampleConfig_202503121220: {
              type: 'groupBox',
              title: 'Sample Config [First Time Setup]',
              children: {
                layout: [
                  {
                    'sampleConfigInt': { xs: 3 },
                    'sampleConfigFloat': { xs: 3 },
                    'sampleConfigString': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'sampleConfigInt': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Sample Config Int',
                      showControls: false,
                      readOnly: false,
                      tagsRelated: ['sampleConfigInt.']
                    }
                  },
                  {
                    'sampleConfigFloat': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Sample Config Float',
                      showControls: false,
                      readOnly: false,
                      tagsRelated: ['sampleConfigFloat.']
                    }
                  },
                  {
                    'sampleConfigString': {
                      type: 'text',
                      placeholder: '',
                      title: 'Sample Config String',
                      tagsRelated: ['sampleConfigString.']
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  ]
}
